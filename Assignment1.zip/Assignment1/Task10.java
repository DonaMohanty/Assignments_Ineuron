package Assignment1;

public class Task10 {

	public static void main(String[] args) {
		String sub[] = {"Java","JavaScript","Selenium","Python","Mukesh"};
		int i=0;
		for(i=0; i<sub.length; i++)
		{
			if(sub[i].equals("Selenium"))
				break;		
		}
		System.out.println(sub[i]);
	}

}
