package Assignment5;

import java.time.Duration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task4 {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		List<WebElement> links = driver.findElements(By.xpath("//div[contains(@class,'orangehrm-login-footer-sm')]/a[@href]"));
		
		for(WebElement ele : links)
		{
			System.out.println("The Href Link is "+ele.getAttribute("href"));
		}
		
		WebElement li = driver.findElement(By.xpath("//a[contains(@href,'linkedin')]"));
		String url1=li.getAttribute("href");
		WebElement fb = driver.findElement(By.xpath("//a[contains(@href,'facebook')]"));
		String url2=fb.getAttribute("href");
		WebElement twr = driver.findElement(By.xpath("//a[contains(@href,'twitter')]"));
		String url3=twr.getAttribute("href");
		WebElement utube = driver.findElement(By.xpath("//a[contains(@href,'youtube')]"));
		String url4=utube.getAttribute("href");
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("Facebook",url1);
		map.put("Twitter",url2);
		map.put("Youtube",url3);
		map.put("LinkedIn",url4);
		
		System.out.println(map);
	
		

	}

}
