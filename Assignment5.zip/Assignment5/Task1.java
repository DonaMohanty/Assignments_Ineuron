package Assignment5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		 driver.manage().window().maximize();
		
		String url=driver.getCurrentUrl();
		
		System.out.println("The current Url is "+url);
		
		if(url.endsWith("login") && url.contains("demo") )
		{
			System.out.println("The Url is valid");
		}
		
		else
			System.out.println("The Url is invalid");
		
		String title=driver.getTitle();
		
		System.out.println("The current title is "+title);
		
		if(title.contains("HRM"))
			System.out.println("The title contains HRM");
			
		else
			
			System.out.println("The title doesn't contains HRM");	
		
			
		
}
}
