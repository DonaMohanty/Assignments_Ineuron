package Assignment5;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task5 {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		List<WebElement> links = driver.findElements(By.xpath("//div[contains(@class,'orangehrm-login-footer-sm')]/a[@href]"));
		
		for(WebElement ele : links)
		{
			if(ele.getAttribute("href").contains("youtube"))
			{
				System.out.println("Youtube Found!!! and the url is " +ele.getAttribute("href"));
				break;
			}
		}
	}

}
