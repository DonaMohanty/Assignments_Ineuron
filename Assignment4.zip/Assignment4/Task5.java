package Assignment4;

import java.util.ArrayList;
import java.util.Arrays;

public class Task5 {

	public static void main(String[] args) {
		
		ArrayList<Integer> list1=new ArrayList<>(Arrays.asList(11,22,33));
		ArrayList<Integer> list2=new ArrayList<>(Arrays.asList(9,19,29));
		ArrayList list3=new ArrayList<>(Arrays.asList(7,17,27));
		
		ArrayList<Integer> list=new ArrayList<>();
		list.addAll(list1);
		list.addAll(list2);
		list.addAll(list3);
		
		System.out.println("List after merging: "+list);
		
		
		

	}

}
