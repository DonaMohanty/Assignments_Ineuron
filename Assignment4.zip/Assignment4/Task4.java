package Assignment4;

import java.util.ArrayList;
import java.util.Arrays;

public class Task4 {

	public static void main(String[] args) {
		ArrayList list=new ArrayList<>(Arrays.asList(10,45, 90,45, 23, 90, 44));
		
		System.out.println("The second element of the list is "+list.get(1));
		System.out.println("The second last element of the list is "+list.get(list.size()-2));

	}

}
