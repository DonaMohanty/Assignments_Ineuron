package Assignment4;

import java.util.ArrayList;

public class Task1 {

	public static void main(String[] args) {
		ArrayList<String> namelist= new ArrayList<String>();
		namelist.add("Java");
		namelist.add("Selenium");
		namelist.add("TestNG");
		namelist.add("Git");
		namelist.add("Github");
		
		System.out.print("Name:"+namelist);
		
		System.out.println("Name in reverse order:");
		for(int i=namelist.size()-1;i>=0;i--)
		{
			System.out.print(namelist.get(i)+" ");
		}
		

	}

}
