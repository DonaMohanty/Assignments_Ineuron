package Assignment4;

import java.util.ArrayList;

public class Task2 {

	public static void main(String[] args) {
		
		ArrayList<String> list=new ArrayList<>();
		list.add("Git");
		list.add("Github");
		list.add("GitLab");
		list.add("GitBash");
		list.add("Selenium");
		list.add("Java");
		list.add("Maven");
		
		
		for (String element : list)
		{
	         if (element.contains("Git"))
	         {
	               System.out.println(element);
	         }
		}

}
}
