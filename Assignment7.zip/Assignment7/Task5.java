package Assignment7;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Task5 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//Task1 in chrome
		String expected_username_msg = "Required";
		String expected_pwd_msg = "Required";
		
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String actual_username_msg = driver.findElement(By.xpath("//label[text()='Username']//following::span[1]")).getText();
		String actual_pwd_msg = driver.findElement(By.xpath("//label[text()='Password']//following::span[1]")).getText();
		
		if(actual_username_msg.equalsIgnoreCase(expected_username_msg) && actual_pwd_msg.equalsIgnoreCase(expected_pwd_msg))
		{
			System.out.println("Require field present for Username and Password");
		}
		else
			System.out.println("Require field does not  present for Username and Password");
		
		String border = driver.findElement(By.xpath("//input[contains(@name,'username')]")).getCssValue("border");
		
		System.out.println("The border size is "+border);
		
		if(border.equalsIgnoreCase("1px"))
		{
			System.out.println("username has a border of 1px.");
		}
		else
			System.out.println("username does not have a border of 1px.");
		
		//Task2 in chrome
		driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		if(actual_pwd_msg.equalsIgnoreCase(expected_pwd_msg))
		{
			System.out.println("Require field present for  Password");
		}
		else
			System.out.println("Require field does not  present for  Password");
		
		//Task3 in chrome
		driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
		driver.findElement(By.xpath("//div/input[contains(@name,'password')]")).sendKeys("mukesh");
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String error_msg = driver.findElement(By.xpath("//p[text()='Invalid credentials']")).getText();
		
		System.out.println("The error message is "+error_msg);
		
		if(error_msg.contains("Invalid credentials"))
		{
			System.out.println("The error message contains Invalid Credentials");
		}
		else
			System.out.println("The error message does not contain Invalid Credentials");
		
		//Task4 in chrome
		driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
		driver.findElement(By.xpath("//div/input[contains(@name,'password')]")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String chromeurl = driver.getCurrentUrl();
		System.out.println("The url is "+chromeurl);
		
		if(chromeurl.contains("dashboard"))
		{
			System.out.println("The url contains dashboard in Chrome Browser");
		}
		else
			System.out.println("The url does not contain dashboard in Chrome Browser");
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Logout']")).click();
		
		String login_url="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		
		if(login_url.equals(driver.getCurrentUrl()))
		{
			System.out.println("After logout the user is able to navigate to the login page in Chrome.");
		}
		else
			System.out.println("After logout the user is not able to navigate to the login page in Chrome.");
		
		
		WebDriver driver1 = new FirefoxDriver();
		driver1.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver1.manage().window().maximize();
		driver1.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//Task1 in firefox
		String expected_username_msg1 = "Required";
		String expected_pwd_msg1 = "Required";
		
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String actual_username_msg1 = driver.findElement(By.xpath("//label[text()='Username']//following::span[1]")).getText();
		String actual_pwd_msg1 = driver.findElement(By.xpath("//label[text()='Password']//following::span[1]")).getText();
		
		if(actual_username_msg1.equalsIgnoreCase(expected_username_msg1) && actual_pwd_msg1.equalsIgnoreCase(expected_pwd_msg1))
		{
			System.out.println("Require field present for Username and Password");
		}
		else
			System.out.println("Require field does not  present for Username and Password");
		
		String border1 = driver.findElement(By.xpath("//input[contains(@name,'username')]")).getCssValue("border");
		
		System.out.println("The border size is "+border1);
		
		if(border1.equalsIgnoreCase("1px"))
		{
			System.out.println("username has a border of 1px.");
		}
		else
			System.out.println("username does not have a border of 1px.");
		
		//Task2 in firefox
				driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
				driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
				
				if(actual_pwd_msg1.equalsIgnoreCase(expected_pwd_msg1))
				{
					System.out.println("Require field present for  Password");
				}
				else
					System.out.println("Require field does not  present for  Password");
				
				//Task3 in firefox
				driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
				driver.findElement(By.xpath("//div/input[contains(@name,'password')]")).sendKeys("mukesh");
				driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
				
				String error_msg1 = driver.findElement(By.xpath("//p[text()='Invalid credentials']")).getText();
				
				System.out.println("The error message is "+error_msg1);
				
				if(error_msg1.contains("Invalid credentials"))
				{
					System.out.println("The error message contains Invalid Credentials");
				}
				else
					System.out.println("The error message does not contain Invalid Credentials");
				
				//Task4 in chrome
		
		//Task4 in firefox
		driver1.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
		driver1.findElement(By.xpath("//div/input[contains(@name,'password')]")).sendKeys("admin123");
		driver1.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String firefoxurl = driver1.getCurrentUrl();
		System.out.println("The url is "+firefoxurl);
		
		if(firefoxurl.contains("dashboard"))
		{
			System.out.println("The url contains dashboard in Firefox");
		}
		else
			System.out.println("The url does not contain dashboard in Firefox");
		
		Thread.sleep(2000);
		driver1.findElement(By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']")).click();
		Thread.sleep(2000);
		driver1.findElement(By.xpath("//li[4]//a[@href='/web/index.php/auth/logout']")).click();
		
		String login_url1="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		
		if(login_url.equals(driver.getCurrentUrl()))
		{
			System.out.println("After logout the user is able to navigate to the login page in Firefox.");
		}
		else
			System.out.println("After logout the user is not able to navigate to the login page in Firefox.");
		
		WebDriver driver2 = new EdgeDriver();
		driver2.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver2.manage().window().maximize();
		driver2.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//Task1 in Edge
		String expected_username_msg2 = "Required";
		String expected_pwd_msg2 = "Required";
		
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String actual_username_msg2 = driver.findElement(By.xpath("//label[text()='Username']//following::span[1]")).getText();
		String actual_pwd_msg2 = driver.findElement(By.xpath("//label[text()='Password']//following::span[1]")).getText();
		
		if(actual_username_msg2.equalsIgnoreCase(expected_username_msg2) && actual_pwd_msg2.equalsIgnoreCase(expected_pwd_msg2))
		{
			System.out.println("Require field present for Username and Password");
		}
		else
			System.out.println("Require field does not  present for Username and Password");
		
		String border2 = driver.findElement(By.xpath("//input[contains(@name,'username')]")).getCssValue("border");
		
		System.out.println("The border size is "+border2);
		
		if(border2.equalsIgnoreCase("1px"))
		{
			System.out.println("username has a border of 1px.");
		}
		else
			System.out.println("username does not have a border of 1px.");
		
		//Task2 in Edge
				driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
				driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
				
				if(actual_pwd_msg2.equalsIgnoreCase(expected_pwd_msg2))
				{
					System.out.println("Require field present for  Password");
				}
				else
					System.out.println("Require field does not  present for  Password");
		
				//Task3 in Edge
				driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
				driver.findElement(By.xpath("//div/input[contains(@name,'password')]")).sendKeys("mukesh");
				driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
				
				String error_msg2 = driver.findElement(By.xpath("//p[text()='Invalid credentials']")).getText();
				
				System.out.println("The error message is "+error_msg2);
				
				if(error_msg2.contains("Invalid credentials"))
				{
					System.out.println("The error message contains Invalid Credentials");
				}
				else
					System.out.println("The error message does not contain Invalid Credentials");
				
				//Task4 in chrome
		//Task4 in Edge
		driver2.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
		driver2.findElement(By.xpath("//div/input[contains(@name,'password')]")).sendKeys("admin123");
		driver2.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String edgeurl = driver2.getCurrentUrl();
		System.out.println("The url is "+edgeurl);
		
		if(edgeurl.contains("dashboard"))
		{
			System.out.println("The url contains dashboard in Edge Browser");
		}
		else
			System.out.println("The url does not contain dashboard in Edge Browser");
		
		Thread.sleep(2000);
		driver2.findElement(By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']")).click();
		driver2.findElement(By.xpath("//a[normalize-space()='Logout']")).click();
		
		String login_url2="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		
		if(login_url.equals(driver.getCurrentUrl()))
		{
			System.out.println("After logout the user is able to navigate to the login page in Edge.");
		}
		else
			System.out.println("After logout the user is not able to navigate to the login page in Edge.");
		
		driver.quit();
		driver1.quit();
		driver2.quit();

	}

}
