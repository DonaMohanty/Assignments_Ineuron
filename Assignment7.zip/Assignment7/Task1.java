package Assignment7;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1 {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		String expected_username_msg = "Required";
		String expected_pwd_msg = "Required";
		
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String actual_username_msg = driver.findElement(By.xpath("//label[text()='Username']//following::span[1]")).getText();
		String actual_pwd_msg = driver.findElement(By.xpath("//label[text()='Password']//following::span[1]")).getText();
		
		if(actual_username_msg.equalsIgnoreCase(expected_username_msg) && actual_pwd_msg.equalsIgnoreCase(expected_pwd_msg))
		{
			System.out.println("Require field present for Username and Password");
		}
		else
			System.out.println("Require field does not  present for Username and Password");
		
		
		
		driver.quit();
		
		
	}

}
