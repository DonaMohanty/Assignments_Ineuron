package Assignment7;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task3 {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
		driver.findElement(By.xpath("//div/input[contains(@name,'password')]")).sendKeys("mukesh");
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String error_msg = driver.findElement(By.xpath("//p[text()='Invalid credentials']")).getText();
		
		System.out.println("The error message is "+error_msg);
		
		if(error_msg.contains("Invalid credentials"))
		{
			System.out.println("The error message contains Invalid Credentials");
		}
		else
			System.out.println("The error message does not contain Invalid Credentials");
		
		driver.quit();

	}

}
