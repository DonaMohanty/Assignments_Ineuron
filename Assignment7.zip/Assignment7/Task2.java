package Assignment7;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task2 {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		String expected_pwd_msg = "Required";
		
		driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
		driver.findElement(By.xpath("//button[@type='submit' and normalize-space()='Login']")).click();
		
		String actual_pwd_msg = driver.findElement(By.xpath("//label[text()='Password']//following::span[1]")).getText();
		
		if(actual_pwd_msg.equalsIgnoreCase(expected_pwd_msg))
		{
			System.out.println("Require field present for  Password");
		}
		else
			System.out.println("Require field does not  present for  Password");
		
		
		
		driver.quit();

	}

}
