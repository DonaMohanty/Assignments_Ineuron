package Assignment10;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Task1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://ineuron-courses.vercel.app/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		driver.findElement(By.xpath("//h2[text()='Sign In']//following::input[1]")).sendKeys("ineuron@ineuron.ai");
		driver.findElement(By.xpath("//h2[text()='Sign In']//following::input[2]")).sendKeys("ineuron");	
//		Thread.sleep(5000);
		WebElement login = driver.findElement(By.xpath("//h2[text()='Sign In']//following::button"));
		js.executeScript("arguments[0].click()", login);
		Thread.sleep(8000);
		//Mouse Hover on manage
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//*/span[text()='Manage']"))).perform();
		
		//Click on Manage courses
		driver.findElement(By.xpath("//*/span[text()='Manage']//following::span[1]")).click();
		Thread.sleep(2000);
		//Click on add new course
		WebElement add = driver.findElement(By.xpath("//button[normalize-space()='Add New Course']"));
		js.executeScript("arguments[0].click()", add);
		
		//Fill all details
		WebElement upload = driver.findElement(By.xpath("//input[@id='thumbnail']"));
		upload.sendKeys("C:\\Users\\Lenovo\\Downloads\\png-transparent-bell-notification-communication-icon-announcement-information-thumbnail.png");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//h3[text()='Course Name']//following::input[1]")).sendKeys("Web Automation using Selenium");
		driver.findElement(By.xpath("//h3[text()='Description']//following::textarea")).sendKeys("The Course includes core java,selenium webdriver,Testng");
		driver.findElement(By.xpath("//h3[text()='Instructor']//following::input[1]")).sendKeys("Mr.Otwani");
		driver.findElement(By.xpath("//h3[text()='Price']//following::input[1]")).sendKeys("8000");
		driver.findElement(By.xpath("//div[normalize-space()='Select Category']")).click();

		List<WebElement> course = driver.findElements(By.xpath("//div[normalize-space()='Select Category']//following::div[1]//button"));
		try {
		for(WebElement ele : course)
		{
			if(ele.getText().equalsIgnoreCase("Selenium"))
			{
				ele.click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			course = driver.findElements(By.xpath("//div[normalize-space()='Select Category']//following::div[1]//button"));
			for(WebElement ele : course)
			{
				if(ele.getText().equalsIgnoreCase("Selenium"))
				{
					ele.click();
				}
			}
		}
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		
		//Delete created course
       driver.findElement(By.xpath("//td[text()='Web Automation using Selenium']//following::button")).click();
		
       //Logout 
		driver.findElement(By.xpath("//button[normalize-space()='Sign out']")).click();	
		Thread.sleep(2000);
		
		
	
		

	}

}
