package Assignment9;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Task1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://ineuron-courses.vercel.app/signup");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		WebElement SignUp = driver.findElement(By.xpath("//*[text()='Sign up']"));
		
		if(SignUp.isDisplayed())
		{
			System.out.println("The Signup button is Disabled");
		}
		else
			System.out.println("The Signup button is Enabled");
		driver.findElement(By.cssSelector("input#name")).sendKeys("Shiv");
		driver.findElement(By.cssSelector("input#email")).sendKeys("none@abc.com");
		driver.findElement(By.cssSelector("input#password")).sendKeys("Dona@13");
		
		List<WebElement> course = driver.findElements(By.xpath("//div[@class='interests-div']//label"));
		
		for(WebElement e : course)
		{
			if(e.getText().equalsIgnoreCase("Testing") ||  e.getText().equalsIgnoreCase("Selenium"))
			{
				e.click();
			}
		}
		
		driver.findElement(By.xpath("//label[text()='Female']")).click();
		
		Select state = new Select(driver.findElement(By.xpath("//select[@id='state']")));
		state.selectByVisibleText("Odisha");
		
		if(SignUp.isEnabled())
		{
			System.out.println("The Signup button is Enabled");
		}
		else
			System.out.println("The Signup button is Disabled");
		
		
		  JavascriptExecutor js = (JavascriptExecutor) driver;
	      js.executeScript("arguments[0].click();", SignUp);
		
		//Validating Created User
//		driver.findElement(By.xpath("//div[@class='navbar-menu-links']/button")).click();
		driver.findElement(By.xpath("//h2[text()='Sign In']//following::input[1]")).sendKeys("none@abc.com");
		driver.findElement(By.xpath("//h2[text()='Sign In']//following::input[2]")).sendKeys("Dona@13");	
		Thread.sleep(2000);
		driver.findElement(By.xpath("//h2[text()='Sign In']//following::button")).click();
		
		String actual_url="https://ineuron-courses.vercel.app/";
		Thread.sleep(2000);
		if(actual_url.equalsIgnoreCase(driver.getCurrentUrl()))
		{
			System.out.println("Login Successful!!!");
		}
		
		else
			System.out.println("Login Unsuccessful!!!");
	Thread.sleep(2000);
	driver.quit();
	}

}
