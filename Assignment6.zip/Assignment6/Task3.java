package Assignment6;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task3 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		WebElement usrname = driver.findElement(By.xpath("//input[contains(@name,'username')]"));
		Thread.sleep(2000);
		WebElement pwd = driver.findElement(By.xpath("//div/input[contains(@name,'password')]"));
		WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
		
		usrname.sendKeys("Admin");
		pwd.sendKeys("admin123");
		login.click();
		
		
		driver.findElement(By.xpath("//li/a/span[text()='Admin']")).click(); //Click on Admin Tab
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click(); //Click on Add button
		
		driver.findElement(By.xpath("//div[@class='oxd-grid-2 orangehrm-full-width-grid']//div[1]//div[1]//div[2]//div[1]//div[1]//div[1]")).click();
		driver.findElement(By.xpath("//div[@role='option']//span[text()='Admin']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[3]/div/div[2]/div/div")).click();
		driver.findElement(By.xpath("//div[@role='option']//span[text()='Disabled']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("TE");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@role='listbox']//div[@role='option'][1]//span")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[4]/div/div[2]/input")).sendKeys("user1997");
		driver.findElement(By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters user-password-cell']//input[@type='password']")).sendKeys("xghost@13RT");
		driver.findElement(By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@type='password']")).sendKeys("xghost@13RT");
		 Thread.sleep(2000);
		WebElement save = driver.findElement(By.xpath("//button[normalize-space()='Save']"));
      // click with Javascript Executor
	      JavascriptExecutor js = (JavascriptExecutor) driver;
	      js.executeScript("arguments[0].click();", save); // no action is performed 
	      
		  driver.navigate().back();
		  
		   //deleting a user
	      driver.findElement(By.xpath("//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[3]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[1]/label[1]/span[1]/i[1]")).click();
	      Thread.sleep(2000);
	      driver.findElement(By.xpath("//button[normalize-space()='Delete Selected']")).click();
	      driver.findElement(By.xpath("//button[normalize-space()='Yes, Delete']")).click();
	      
		  driver.findElement(By.xpath("//h5[text()='System Users']//following::input[1]")).sendKeys("User2023");//xpath is correct, throwing no such element exception
		  driver.findElement(By.xpath("//button[normalize-space()='Search']")).click();
	     
	   
	      driver.quit();
	}

}
