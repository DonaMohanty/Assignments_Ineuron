package Assignment6;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1 {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		//3 xpath for username
		
		WebElement usrname1= driver.findElement(By.xpath("//input[contains(@name,'username')]"));
		WebElement usrname2= driver.findElement(By.xpath("//div/following::input[@name='username']"));
		//WebElement usrname3= driver.findElement(By.xpath("(//input[@name='username'])[1]"));
		
		//3 css selector for username
		
		driver.findElement(By.cssSelector("input[name='username']"));
		driver.findElement(By.cssSelector("input[name^='user']"));
		driver.findElement(By.cssSelector("input[name$='name']"));
		
		//3 xpath for password
		driver.findElement(By.xpath("//div/input[contains(@name,'password')]"));
		driver.findElement(By.xpath("//input[@name='username']/self::input"));
		driver.findElement(By.xpath("//input[@name='password'][1]"));
		
		//3 css selector for password
		driver.findElement(By.cssSelector("input[placeholder*='sswor']"));
		driver.findElement(By.cssSelector("input[name='password']"));
		driver.findElement(By.cssSelector("div>input[name^='pass']"));
		
		//3 xpath for Login button
		driver.findElement(By.xpath("//div/button[contains(@type,'submit')]"));
		driver.findElement(By.xpath("//form/div/following::button"));
		driver.findElement(By.xpath("(//button[normalize-space()='Login'])"));
		
		
		//3 css selector for Login button
		driver.findElement(By.cssSelector("button[type='submit']"));
		driver.findElement(By.cssSelector("div>button[type='submit']"));
		driver.findElement(By.cssSelector("div button"));
		
		driver.quit();
		
	}

}
