package Assignment3;


import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Task4 {

	public static void main(String[] args) {
		List<Integer> num =Arrays.asList(13,43,87,99,93,6);
		
		int sum=0;
		
		System.out.print("Sum: ");
		Iterator<Integer> itr= num.iterator();
		while(itr.hasNext())
		{
			sum+=itr.next();
		}
	
		System.out.print(sum);
	}

}
