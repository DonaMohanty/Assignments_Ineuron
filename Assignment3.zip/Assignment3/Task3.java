package Assignment3;

import java.util.ArrayList;
import java.util.Iterator;

public class Task3 {

	public static void main(String[] args) {
		ArrayList<Integer> List = new ArrayList<Integer>();
		List.add(51);
		List.add(74);
		List.add(11);
		List.add(81);
		List.add(66);
		List.add(39);
		List.add(17);
		
		System.out.print("List Elements are: ");
		Iterator<Integer> itr=List.iterator();
		
		while(itr.hasNext()) {
			System.out.print(" "+itr.next());
		}
		

	}

}
