package Assignment3;

import java.util.ArrayList;

public class Task7 {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<>();
		list.add("Web Automation");
		list.add("API Automation");
		list.add("Mobile Automation");
		
		if(list.contains("Mobile Automation"))
		{
			System.out.print(true);
		}
		
		else
			System.out.print(false);

	}

}
