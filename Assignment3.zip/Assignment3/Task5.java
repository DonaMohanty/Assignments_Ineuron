package Assignment3;

import java.util.ArrayList;
import java.util.List;

public class Task5 {

	public static void main(String[] args) {
		int arr[]={0,1,2,3,4,5,6};
		
		List<Integer> list=new ArrayList<Integer>();
		
		for(int i=0;i<arr.length;i++)
		{
			list.add(arr[i]);
		}
		
		System.out.println("List Elements: "+list);

	}

}
