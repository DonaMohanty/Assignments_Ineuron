package Assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Task6 {

	public static void main(String[] args) {
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(33);
		list.add(44);
		list.add(55);
		list.add(66);
		list.add(77);
		list.add(88);
		System.out.println(list);
		
		list.remove(1);//remove second element using index
		System.out.println(list);
		
		//Now list is [33, 55, 66, 77, 88],removing second element(i.e 55) using value
		list.remove(Integer.valueOf(55));
		System.out.println(list);
		
		//Add 90 at index 3
		list.set(3, 90);
		System.out.println(list);
		
		//Get the length of list
		System.out.println("The Length of List is "+list.size());
		
		//Print all values from list using any values
		
		List<String> list1=Arrays.asList("Dona","Anup","Preeti","Archana","Tina");
		System.out.print("The list values: ");
		for(String names:list1)
		{
			System.out.print(names+" ");
		}
		
		System.out.println();
		//Convert List into array
		int arr[]=new int[10];
		System.out.print("Array from List: ");
		for(int i = 0;i<list.size();i++)
		{
			arr[i]=list.get(i);
			System.out.print(arr[i]+" ");
		}
		
		
	}

}
