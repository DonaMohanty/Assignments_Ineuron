package Assignment3;

import java.util.ArrayList;

public class Task2 {

	public static void main(String[] args) {
		
		ArrayList<Integer> List = new ArrayList<Integer>();
		List.add(21);
		List.add(62);
		List.add(23);
		List.add(14);
		List.add(85);
		List.add(96);
		List.add(57);
		
		System.out.print("List Elements are: ");
		for(int list1:List)
		{
			System.out.print(list1+ " ");
		}
	}

}
