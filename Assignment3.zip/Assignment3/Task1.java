package Assignment3;

import java.util.ArrayList;

public class Task1 {

	public static void main(String[] args) {
		ArrayList<Integer> List = new ArrayList<Integer>();
		List.add(21);
		List.add(22);
		List.add(23);
		List.add(24);
		List.add(25);
		List.add(26);
		List.add(27);
		
		System.out.print("List Elements are: ");
		for(int i=0;i<List.size();i++)
		{
			System.out.print(List.get(i)+ " ");
		}

	}

}
