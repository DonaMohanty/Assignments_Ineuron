package Assignment2;

public class Trainer {
	
	String name,department,email;
	int id;
	
	public Trainer(String e_name,String dept, String mail, int e_id)
	{
		name=e_name;
		department=dept;
		email=mail;
		id=e_id;
	}
	
	public void display()
	{
		System.out.println(name+","+department+","+email+","+id);
	}

	public static void main(String[] args) {
		
		Trainer trainer1= new Trainer( "Mukesh" ,"Testing","mukesh@gmail.com", 1);
		Trainer trainer2= new Trainer(  "Hitesh" ,"Dev","mukesh@gmail.com", 2);
		Trainer trainer3= new Trainer(  "Mukesh" ,"DevOps","mukesh@gmail.com", 3);
		
		trainer1.display();
		trainer2.display();
		trainer3.display();
		
	
	}

}
