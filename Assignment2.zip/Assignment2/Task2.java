package Assignment2;

public class Task2 {

	public static void main(String[] args) {
		
		Object trainer[][]= {{"Mukesh " ,"Testing ","mukesh@gmail.com ",1},{"Hitesh " ,"Dev ","mukesh@gmail.com ",2},{"Mukesh " ,"DevOps ","mukesh@gmail.com ",3}};
		
		for(Object[] trainers:trainer) {
			for(Object obj:trainers)
			{
				System.out.print(obj);	
		}
			System.out.println();
		
	

}
}
}
