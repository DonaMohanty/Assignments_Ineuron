package Assignment2;
import java.util.*;
public class Task3 {
	long phone;
	String name, email, address, status;
	static Scanner sc=new Scanner(System.in);
	public void getData()
	{
		System.out.println("Enter the name:");
		name=sc.next();
		System.out.println("Enter the phone:");
		phone=sc.nextLong();
		System.out.println("Enter the email:");
		email=sc.next();
		System.out.println("Enter the address:");
		address=sc.next();
		System.out.println("Enter the status:");
		status=sc.next();
	}
	
	public void display()
	{
		System.out.println(name);
		System.out.println(phone);
		System.out.println(email);
		System.out.println(address);
		System.out.println(status);
	}
	
	public static void main(String[] args) {
		
		Task3 obj1=new Task3();
		Task3 obj2=new Task3();
		Task3 obj3=new Task3();
		
		obj1.getData();
		obj2.getData();
		obj3.getData();
		
		System.out.println("Please Enter the student details you want to display: ");
		int op=sc.nextInt();
		
		switch(op)
		{
			case 1:
			obj1.display();
			break;
			
			case 2:
				obj2.display();
				break;
			
			case 3:
				obj3.display();
				break;
			default:
				System.out.println("Incorrect Entry!!");
		}
	}

}
