package Assignment8;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task2 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		List<WebElement> href_list = driver.findElements(By.xpath("//div[@id='pageFooterChildren']//ul[contains(@class,'uiList pageFooterLinkList')]//child::li"));
		System.out.println("All the links available in footer are: ");
		for(WebElement e : href_list)
		{
			System.out.println(e.getText());
		}
		
		WebElement  create_page_link = driver.findElement(By.xpath("//a[normalize-space()='Create a Page']"));
		
		if(create_page_link.isDisplayed() && create_page_link.isEnabled())
		{
			System.out.println("The link is displayed and enabled");
			create_page_link.click();
		}
		
		else
			System.out.println("The link isn't displayed and enabled");
		
		
		Thread.sleep(1500);
		driver.quit();

	}

}
