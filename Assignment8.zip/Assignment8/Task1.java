package Assignment8;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		String text = driver.findElement(By.xpath("//h2[contains(text(),'Facebook')]")).getText();
		
		String actual_text = "Facebook helps you connect and share with the people in your life.";
		
		System.out.println("The visible text is "+text);
		
		if(text.equals(actual_text))
		{
			System.out.println("The text are matching");
		}
		else
			System.out.println("The text are not matching");
		
		Thread.sleep(1500);
		driver.quit();

	}

}
