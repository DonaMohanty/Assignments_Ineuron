package Assignment8;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Task4 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.cssSelector("a[ajaxify='/reg/spotlight/']")).click();
		driver.findElement(By.cssSelector("input[placeholder='First name']")).sendKeys("Payal");
		driver.findElement(By.cssSelector("input[name='lastname']")).sendKeys("Sen");
		driver.findElement(By.cssSelector("input[name='reg_email__']")).sendKeys("986123396");
		driver.findElement(By.cssSelector("input#password_step_input")).sendKeys("Password@309");
		
		Select date = new Select(driver.findElement(By.cssSelector("select#day")));
		List<WebElement> dates = date.getOptions();
		
		for(WebElement d : dates)
		{
			
			if(d.getText().equalsIgnoreCase("31"))
			{
				d.click();
				break;
			}
				
		}
		
		Select month = new Select(driver.findElement(By.cssSelector("select#month")));
		List<WebElement> months = month.getOptions();
		
		for(WebElement m : months)
		{
			
			if(m.getText().equalsIgnoreCase("Feb"))
			{
				m.click();
				break;
			}
				
		}
		
		Select year = new Select(driver.findElement(By.cssSelector("select#year")));
		List<WebElement> years = year.getOptions();
		
		for(WebElement y : years)
		{
			
			if(y.getText().equalsIgnoreCase("1998"))
			{
				y.click();
				break;
			}
				
		}
		driver.findElement(By.cssSelector("input[value='1']")).click();
		driver.findElement(By.cssSelector("button[name='websubmit']")).click();
		
		
		Thread.sleep(1500);
		driver.quit();

	}

}
