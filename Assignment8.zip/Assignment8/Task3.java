package Assignment8;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Task3 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//a[normalize-space()='Create new account']")).click();
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Zack");
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Dsouza");
		driver.findElement(By.xpath("//input[@name='reg_email__']")).sendKeys("986123396");
		driver.findElement(By.xpath("//input[@id='password_step_input']")).sendKeys("Password@309");
		
		Select date = new Select(driver.findElement(By.xpath("//select[@name='birthday_day']")));
		List<WebElement> dates = date.getOptions();
		
		for(WebElement d : dates)
		{
			
			if(d.getText().equalsIgnoreCase("31"))
			{
				d.click();
				break;
			}
				
		}
		
		Select month = new Select(driver.findElement(By.xpath("//select[@name='birthday_month']")));
		List<WebElement> months = month.getOptions();
		
		for(WebElement m : months)
		{
			
			if(m.getText().equalsIgnoreCase("Feb"))
			{
				m.click();
				break;
			}
				
		}
		
		Select year = new Select(driver.findElement(By.xpath("//select[@name='birthday_year']")));
		List<WebElement> years = year.getOptions();
		
		for(WebElement y : years)
		{
			
			if(y.getText().equalsIgnoreCase("1998"))
			{
				y.click();
				break;
			}
				
		}
		driver.findElement(By.xpath("//label[text()='Male']")).click();
		driver.findElement(By.xpath("//a[@href='/policies/cookies/']//following::button[normalize-space()='Sign Up'][1]")).click();
		//driver.findElement(By.xpath(""));
		
		
		
		Thread.sleep(1500);
		driver.quit();
		
	}

}
